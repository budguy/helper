﻿namespace AttackBuddy.IPCMessages
{
    public enum IPCOpcode
    {
        Start = 1001,
        Stop = 1002,
        AttackRange = 1003,
        ScanRange = 1004
    }
}
