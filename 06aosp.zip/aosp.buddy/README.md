Buddies provide some automation for certain tasks.

Only inject One buddy at a time to avoid conflicts and issues.
