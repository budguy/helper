﻿namespace DefendBuddy.IPCMessages
{
    public enum IPCOpcode
    {
        Start = 1001,
        Stop = 1002,
        SetPos = 1003,
        SetResetPos = 1004,
        AttackRange = 1005,
        ScanRange = 1006
    }
}
