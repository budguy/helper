﻿using AOSharp.Common.GameData;
using AOSharp.Common.SharedEventArgs;
using AOSharp.Core;
using AOSharp.Core.Movement;
using AOSharp.Core.UI;
using SmokeLounge.AOtomation.Messaging.Messages.N3Messages;
using System.Threading;
using System.Threading.Tasks;

namespace Neko
{
    public class Main : AOPluginEntry
    {
        //TODO: Convert to settings/UI
        private bool _walkOnWater = true;
        private bool _fullAggCasting = true;
        private bool _castInstantSpellsWhileMoving = true;
        private ManualResetEvent _resumeMovingTrigger = new ManualResetEvent(false);

        public override void Run(string pluginDir)
        {
            Chat.RegisterCommand("1shd", (string command, string[] param, ChatWindow chatWindow) =>
            {
                MovementController.Instance.SetMovement(MovementAction.SwitchToSit);
                MovementController.Instance.SetMovement(MovementAction.SwitchToSwim);
                MovementController.Instance.SetMovement(MovementAction.LeaveSwim);
            });

            DynelCastSpellPatcher.Patch();
            Game.OnUpdate += OnUpdate;
            MiscClientEvents.AttemptingSpellCast += AttemptingSpellCast;
        }

        private void OnUpdate(object s, float deltaTime)
        {
            if (_walkOnWater && DynelManager.LocalPlayer.MovementState == MovementState.Swim)
                MovementController.Instance.SetMovement(MovementAction.LeaveSwim);

            if(_resumeMovingTrigger.WaitOne(0))
            {
                Network.Send(new CharDCMoveMessage
                {
                    MoveType = MovementAction.ForwardStart,
                    Heading = DynelManager.LocalPlayer.Rotation,
                    Position = DynelManager.LocalPlayer.Position,
                });

                _resumeMovingTrigger.Reset();
            }    
        }

        public override void Teardown()
        {
            DynelCastSpellPatcher.Unpatch();
        }

        private void AttemptingSpellCast(object sender, AttemptingSpellCastEventArgs e)
        {
            if (Spell.Find(e.Nano.Instance, out Spell spell))
            {
                if (_fullAggCasting)
                {
                    e.Block();

                    Network.Send(new SetStatMessage
                    {
                        Stat = Stat.AggDef,
                        Value = 100
                    });
                }

                if (_castInstantSpellsWhileMoving && DynelManager.LocalPlayer.IsMoving)
                {
                    e.Block();

                    Network.Send(new CharDCMoveMessage
                    {
                        MoveType = MovementAction.FullStop,
                        Heading = DynelManager.LocalPlayer.Rotation,
                        Position = DynelManager.LocalPlayer.Position,
                    });

                    Task.Delay(200).ContinueWith((_) => _resumeMovingTrigger.Set());
                }

                if(e.Blocked)
                    spell.Cast();

                if (_fullAggCasting)
                {
                    Network.Send(new SetStatMessage
                    {
                        Stat = Stat.AggDef,
                        Value = DynelManager.LocalPlayer.GetStat(Stat.AggDef)
                    });
                }
            }
        }
    }
}
