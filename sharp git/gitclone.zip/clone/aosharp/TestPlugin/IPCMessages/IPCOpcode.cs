﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestPlugin.IPCMessages
{
    public enum IPCOpcode
    {
        Test = 1,
        Empty = 2
    }
}
