As this project is reaching a usable state I've created some additional repos to store plugins managed by me.

https://gitlab.com/never-knows-best/aosharp.bots
https://gitlab.com/never-knows-best/aosharp-automation

Syntax is bound to change frequently as the code expands so deal with it.

https://discord.gg/UyVD7C9 for any questions/requests