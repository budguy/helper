﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AOSharp.Common.GameData;

namespace OSTBuddy
{
    public static class Constants
    {
        public static Vector3 _posToDefend;
        public static Vector3 DefendPos = new Vector3(165.6f, 2.2f, 186.1f);
    }
}
