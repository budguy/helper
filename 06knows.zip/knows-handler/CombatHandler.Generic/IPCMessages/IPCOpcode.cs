﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CombatHandler.Generic.IPCMessages
{
    public enum IPCOpcode
    {
        Disband = 2100,
        ClearBuffs = 2101
    }
}
