﻿using AOSharp.Core;
using AOSharp.Core.Movement;
using AOSharp.Core.UI;
using System.Linq;
//using static MitaarBuddy.MitaarBuddy;

namespace MitaarBuddy
{
    public class MediumState : IState
    {

        private static SimpleChar _sinuh;
        private static Corpse _sinuhCorpse;

        private static SimpleChar _alienCoccoon;

        private static SimpleChar _xanSpirits;
        private static SimpleChar _redXanSpirit;

        public IState GetNextState()
        {

            _alienCoccoon = DynelManager.NPCs
               .Where(c => c.Health > 0
                       && c.Name.Contains("Alien Coccoon"))
                   .FirstOrDefault();

            _xanSpirits = DynelManager.NPCs
                .Where(c => c.Health > 0
                    && c.Name.Contains("Xan Spirit"))
                    .FirstOrDefault();

            if (Extensions.HasDied())
                return new DiedState();

            if (Playfield.ModelIdentity.Instance == Constants.XanHubId
                && !Team.IsInTeam
                && DynelManager.LocalPlayer.Position.DistanceFrom(Constants._entrance) <= 10f)
                return new ReformState();

            if (MitaarBuddy.SinuhCorpse
                && _xanSpirits == null
                && _alienCoccoon == null
                && Extensions.CanProceed()
                && MitaarBuddy._settings["Farming"].AsBool())
                return new FarmingState();

            return null;
        }

        public void OnStateEnter()
        {
            Chat.WriteLine("Start on Red, Medium Mode");
            if (DynelManager.LocalPlayer.Position.DistanceFrom(Constants._redPodium) > 0.9f)
            { 
                MovementController.Instance.SetDestination(Constants._startPosition); 
            }
        }

        public void OnStateExit()
        {
                Chat.WriteLine("Medium over");
        }

        public void Tick()
        {
            if (!Team.IsInTeam || Game.IsZoning) { return; }

            foreach (TeamMember member in Team.Members)
            {
                if (!ReformState._teamCache.Contains(member.Identity))
                    ReformState._teamCache.Add(member.Identity);
            }

            MitaarBuddy._leader = Team.Members
                .Where(c => c.Character?.Health > 0
                    && c.Character?.IsValid == true
                    && c.IsLeader)
                .FirstOrDefault()?.Character;

            if (Playfield.ModelIdentity.Instance == 6017)
            {
                _sinuh = DynelManager.NPCs
                 .Where(c => c.Health > 0
                  && c.Name.Contains("Technomaster Sinuh")
                  && !c.Name.Contains("Remains of"))
                  .FirstOrDefault();

                _alienCoccoon = DynelManager.NPCs
                   .Where(c => c.Health > 0
                           && c.Name.Contains("Alien Coccoon"))
                       .FirstOrDefault();

                _redXanSpirit = DynelManager.NPCs
                    .Where(c => c.Health > 0
                        && c.Name.Contains("Xan Spirit")
                        && c.Buffs.Contains(MitaarBuddy.SpiritNanos.BlessingofTheBlood))
                        .FirstOrDefault();

                _sinuhCorpse = DynelManager.Corpses
                  .Where(c => c.Name.Contains("Remains of Technomaster Sinuh"))
                      .FirstOrDefault();


                if (_sinuhCorpse != null)
                    MitaarBuddy.SinuhCorpse = true;

                //Attack and initial start
                if (_sinuh != null && _alienCoccoon == null)
                {
                    if (DynelManager.LocalPlayer.FightingTarget == null && !DynelManager.LocalPlayer.IsAttackPending)
                        DynelManager.LocalPlayer.Attack(_sinuh);
                }

                if (_sinuh != null && _alienCoccoon != null)
                {
                    if (DynelManager.LocalPlayer.FightingTarget != null
                        && DynelManager.LocalPlayer.FightingTarget.Name == _sinuh.Name)
                    {
                        DynelManager.LocalPlayer.StopAttack();
                    }
                }

                if (_alienCoccoon != null)
                {
                    if (DynelManager.LocalPlayer.FightingTarget == null && !DynelManager.LocalPlayer.IsAttackPending)
                    {
                        DynelManager.LocalPlayer.Attack(_alienCoccoon);
                    }
                }

                //Pathing to spirits
                if (_xanSpirits != null && !MovementController.Instance.IsNavigating)
                {
                    if (_redXanSpirit != null && DynelManager.LocalPlayer.Position.DistanceFrom(Constants._redPodium) > 0.9f
                        && !DynelManager.LocalPlayer.Buffs.Contains(MitaarBuddy.SpiritNanos.BlessingofTheBlood))
                        MovementController.Instance.SetDestination(Constants._redPodium);

                }
            }
        }
    }
}