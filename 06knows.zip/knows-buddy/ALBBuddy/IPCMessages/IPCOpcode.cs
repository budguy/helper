﻿namespace ALBBuddy.IPCMessages
{
    public enum IPCOpcode
    {
        Start = 1951,
        Stop = 1952
    }
}
