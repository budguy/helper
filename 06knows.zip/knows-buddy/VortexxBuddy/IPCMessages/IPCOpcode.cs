﻿namespace VortexxBuddy.IPCMessages
{
    public enum IPCOpcode
    {
        Start = 1011,
        Stop = 1012,
        Farming = 1013,
        NoFarming = 1014,
        Enter = 1015
    }
}
