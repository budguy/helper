﻿using AOSharp.Common;
using AOSharp.Common.GameData;
using AOSharp.Common.Unmanaged.DbObjects;
using AOSharp.Common.Unmanaged.Interfaces;
using AOSharp.Core;
using AOSharp.Core.UI;
using org.critterai.geom;
using org.critterai.nav;
using org.critterai.nmbuild;
using org.critterai.nmgen;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace NavGen
{
    public class NavGen : AOPluginEntry
    {
        public static Config Config;
        private NavGenWindow _window;

        public override void Run(string pluginDir)
        {
            Config = Config.Load();
            _window = new NavGenWindow(pluginDir);

            Chat.RegisterCommand("navgen", (command, param, chatWindow) =>
            {
                _window.Show();
            });

            Game.OnUpdate += _window.OnUpdate;
            //Game.TeleportEnded += _window.OnZoned;
        }
    }
}
