﻿using AOSharp.Common.GameData;
using AOSharp.Core;
using AOSharp.Core.Movement;
using AOSharp.Core.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AXPBuddy
{
    public class EnterSectorState : IState
    {
        private const int MinWait = 8;
        private const int MaxWait = 10;
        private CancellationTokenSource _cancellationToken = new CancellationTokenSource();

        public IState GetNextState()
        {
            if (Playfield.ModelIdentity.Instance == Constants.S13Id)
            {
                if (AXPBuddy.ModeSelection.Leech == (AXPBuddy.ModeSelection)AXPBuddy._settings["ModeSelection"].AsInt32())
                    return new LeechState();

                return new PatrolState();
            }

            return null;
        }

        public void OnStateEnter()
        {
            //Chat.WriteLine("EnterSectorState::OnStateEnter");

            if (AXPBuddy._settings["Merge"].AsBool() && !AXPBuddy._started)
            {
                AXPBuddy._started = true;
            }

            if (DynelManager.LocalPlayer.Identity == AXPBuddy.Leader)
            {
                Task.Delay(2 * 1000).ContinueWith(x =>
                {
                    AXPBuddy.NavMeshMovementController.SetNavMeshDestination(Constants.S13EntrancePos);
                }, _cancellationToken.Token);
            }
            else if (AXPBuddy.ModeSelection.Leech == (AXPBuddy.ModeSelection)AXPBuddy._settings["ModeSelection"].AsInt32())
            {
                if (!AXPBuddy._settings["Merge"].AsBool())
                {
                    Task.Delay(5 * 1000).ContinueWith(x =>
                    {
                        AXPBuddy.NavMeshMovementController.SetNavMeshDestination(Constants.S13EntrancePos);
                    }, _cancellationToken.Token);
                }
                else
                {
                    Task.Delay(7 * 1000).ContinueWith(x =>
                    {
                        AXPBuddy.NavMeshMovementController.SetNavMeshDestination(Constants.S13EntrancePos);
                    }, _cancellationToken.Token);
                }
            }
            else
            {
                int randomWait = Utils.Next(MinWait, MaxWait);
                Chat.WriteLine($"Idling for {randomWait} seconds..");

                Task.Delay(randomWait * 1000).ContinueWith(x =>
                {
                    AXPBuddy.NavMeshMovementController.SetNavMeshDestination(Constants.S13EntrancePos);
                }, _cancellationToken.Token);
            }
        }

        public void OnStateExit()
        {
            //Chat.WriteLine("EnterSectorState::OnStateExit");

            _cancellationToken.Cancel();
        }

        public void Tick()
        {
            if (Game.IsZoning)
                return;
        }
    }
}