﻿using AOSharp.Common.GameData;
using AOSharp.Core;
using AOSharp.Core.IPC;
using AOSharp.Core.Movement;
using AOSharp.Core.UI;
using KHBuddy.IPCMessages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KHBuddy
{
    public class PullState : IState
    {
        public static int _counterVec = 0;

        public static bool CastedMongo = false;

        public static bool _initWest = false;
        public static bool _initEast = false;
        public static bool _initBeach = false;

        private double _lastFollowTime = Time.NormalTime;

        public static IPCChannel IPCChannel { get; private set; }

        #region Vectors

        public static List<Vector3> KHBeachVectorList = new List<Vector3>
        {
            new Vector3(898.1f, 4.4f, 289.9f),
            new Vector3(926.5f, 1.6f, 228.9f),
            new Vector3(1006.0f, 1.6f, 202.3f),
            new Vector3(1027.8f, 1.6f, 209.4f),
            new Vector3(1042.1f, 1.6f, 229.1f),
            new Vector3(1062.6f, 1.6f, 250.0f),
            new Vector3(1079.7f, 1.6f, 270.4f),
            new Vector3(1090.6f, 1.6f, 291.4f),
            new Vector3(1101.9f, 1.6f, 310.0f),
            new Vector3(1109.0f, 1.6f, 337.5f),
            new Vector3(1114.5f, 1.6f, 359.9f),
            new Vector3(1117.3f, 1.6f, 386.7f),
            new Vector3(1123.7f, 1.6f, 408.1f),
            new Vector3(1128.1f, 1.6f, 434.3f),
            new Vector3(1138.7f, 1.6f, 457.6f),
            new Vector3(1141.8f, 1.6f, 485.2f),
            new Vector3(1153.2f, 1.6f, 503.4f),
            new Vector3(1154.8f, 1.6f, 525.6f),
            new Vector3(1158.9f, 1.6f, 546.4f),
            new Vector3(1164.1f, 1.6f, 568.5f),
            new Vector3(1160.7f, 1.6f, 585.0f),
            new Vector3(1152.2f, 1.6f, 600.5f),
            new Vector3(1155.0f, 1.6f, 625.7f),
            new Vector3(1159.0f, 1.6f, 607.4f),
            new Vector3(1164.0f, 1.6f, 585.6f),
            new Vector3(1158.8f, 1.6f, 561.1f),
            new Vector3(1157.0f, 1.6f, 538.1f),
            new Vector3(1155.6f, 1.6f, 515.6f),
            new Vector3(1148.2f, 1.6f, 492.8f),
            new Vector3(1143.9f, 1.6f, 470.0f),
            new Vector3(1137.8f, 1.6f, 449.3f),
            new Vector3(1134.5f, 1.6f, 428.9f),
            new Vector3(1127.3f, 1.6f, 409.1f),
            new Vector3(1122.0f, 1.6f, 388.0f),
            new Vector3(1119.7f, 1.6f, 365.7f),
            new Vector3(1114.3f, 1.6f, 342.0f),
            new Vector3(1107.9f, 1.6f, 316.2f),
            new Vector3(1096.0f, 1.6f, 295.7f),
            new Vector3(1089.2f, 1.6f, 270.5f),
            new Vector3(1071.2f, 1.6f, 256.9f),
            new Vector3(1058.7f, 1.6f, 241.5f),
            new Vector3(1047.0f, 1.6f, 227.1f),
            new Vector3(1037.3f, 1.6f, 212.0f),
            new Vector3(1026.4f, 1.6f, 194.4f),
            new Vector3(1003.9f, 1.6f, 196.3f),
            new Vector3(988.7f, 1.6f, 202.3f),
            new Vector3(976.1f, 1.6f, 212.5f),
            new Vector3(960.4f, 1.6f, 225.1f),
            new Vector3(938.1f, 1.6f, 228.4f),
            new Vector3(922.7f, 1.6f, 237.8f),
            new Vector3(911.5f, 1.6f, 254.1f),
            new Vector3(905.3f, 2.6f, 269.4f),
            new Vector3(903.0f, 4.3f, 284.3f),
            new Vector3(901.9f, 4.4f, 299.6f),
            new Vector3(901.9f, 4.4f, 299.6f),
            new Vector3(901.9f, 4.4f, 299.6f)
        };

        public static List<Vector3> KHEastVectorList = new List<Vector3>
        {
            new Vector3(1115.9f, 1.6f, 1064.3f),
            new Vector3(1121.3f, 1.6f, 1054.8f),
            new Vector3(1126.1f, 1.6f, 1041.5f),
            new Vector3(1131.4f, 1.6f, 1029.1f),
            new Vector3(1135.1f, 1.6f, 1002.2f),
            new Vector3(1136.1f, 1.6f, 981.7f),
            new Vector3(1137.7f, 1.6f, 953.0f),
            new Vector3(1136.7f, 1.6f, 928.5f),
            new Vector3(1135.6f, 1.6f, 906.8f),
            new Vector3(1132.6f, 1.6f, 883.0f),
            new Vector3(1131.3f, 2.0f, 862.9f),
            new Vector3(1123.6f, 1.6f, 841.5f),
            new Vector3(1120.5f, 1.6f, 816.2f),
            new Vector3(1136.3f, 1.6f, 781.3f),
            new Vector3(1157.9f, 2.0f, 768.7f),
            new Vector3(1187.4f, 1.6f, 769.3f),
            new Vector3(1203.7f, 1.6f, 780.8f),
            new Vector3(1220.3f, 1.6f, 796.1f),
            new Vector3(1233.3f, 1.6f, 808.0f),
            new Vector3(1244.5f, 1.6f, 818.7f),
            new Vector3(1260.5f, 1.6f, 818.4f),
            new Vector3(1258.7f, 1.6f, 800.2f),
            new Vector3(1250.2f, 1.6f, 784.3f),
            new Vector3(1236.3f, 1.6f, 772.4f),
            new Vector3(1225.8f, 1.6f, 759.8f),
            new Vector3(1221.1f, 1.6f, 741.2f),
            new Vector3(1220.8f, 1.6f, 722.7f),
            new Vector3(1226.4f, 1.6f, 705.9f),
            new Vector3(1231.6f, 1.6f, 690.7f),
            new Vector3(1220.1f, 1.6f, 680.1f),
            new Vector3(1204.2f, 1.6f, 681.1f),
            new Vector3(1187.8f, 1.6f, 678.7f),
            new Vector3(1170.8f, 1.6f, 675.9f),
            new Vector3(1166.0f, 1.6f, 663.5f),
            new Vector3(1164.4f, 1.6f, 647.2f),
            new Vector3(1149.5f, 1.6f, 649.3f),
            new Vector3(1134.0f, 1.6f, 651.5f),
            new Vector3(1120.0f, 1.6f, 645.0f),
            new Vector3(1109.7f, 1.6f, 639.9f),
            new Vector3(1094.9f, 1.6f, 646.2f),
            new Vector3(1078.2f, 1.6f, 648.3f),
            new Vector3(1073.1f, 1.6f, 667.4f),
            new Vector3(1061.1f, 1.6f, 688.5f),
            new Vector3(1052.1f, 1.6f, 706.4f),
            new Vector3(1045.3f, 1.6f, 720.2f),
            new Vector3(1055.9f, 1.6f, 731.8f),
            new Vector3(1061.5f, 1.6f, 751.5f),
            new Vector3(1065.7f, 1.6f, 771.5f),
            new Vector3(1072.0f, 1.6f, 786.9f),
            new Vector3(1086.4f, 1.6f, 781.8f),
            new Vector3(1099.6f, 1.6f, 769.2f),
            new Vector3(1096.8f, 1.6f, 787.9f),
            new Vector3(1090.1f, 1.6f, 803.8f),
            new Vector3(1083.2f, 1.6f, 813.7f),
            new Vector3(1097.9f, 1.6f, 820.7f),
            new Vector3(1111.2f, 1.6f, 826.2f),
            new Vector3(1128.6f, 1.6f, 827.1f),
            new Vector3(1134.3f, 1.6f, 847.0f),
            new Vector3(1134.3f, 1.6f, 863.2f),
            new Vector3(1132.4f, 1.6f, 880.5f),
            new Vector3(1128.4f, 1.6f, 901.4f),
            new Vector3(1133.5f, 1.6f, 920.8f),
            new Vector3(1135.8f, 1.6f, 938.6f),
            new Vector3(1137.2f, 1.6f, 957.3f),
            new Vector3(1137.9f, 1.6f, 976.9f),
            new Vector3(1116.9f, 1.6f, 992.6f),
            new Vector3(1099.9f, 1.6f, 978.5f),
            new Vector3(1082.2f, 1.6f, 963.9f),
            new Vector3(1096.4f, 1.6f, 979.8f),
            new Vector3(1105.8f, 1.6f, 984.8f),
            new Vector3(1123.2f, 1.6f, 994.0f),
            new Vector3(1130.0f, 1.6f, 1009.0f),
            new Vector3(1140.5f, 1.6f, 1017.6f),
            new Vector3(1143.0f, 1.6f, 1035.7f),
            new Vector3(1150.5f, 1.6f, 1051.6f),
            new Vector3(1163.6f, 1.6f, 1068.0f),
            new Vector3(1180.5f, 1.6f, 1084.5f),
            new Vector3(1199.1f, 1.6f, 1078.2f),
            new Vector3(1217.2f, 1.6f, 1062.6f),
            new Vector3(1210.1f, 1.6f, 1085.9f),
            new Vector3(1184.1f, 1.6f, 1088.6f),
            new Vector3(1159.4f, 1.6f, 1083.6f),
            new Vector3(1122.0f, 1.6f, 1069.1f),
            new Vector3(1115.9f, 1.6f, 1064.3f),
            new Vector3(1115.9f, 1.6f, 1064.3f)
        };

        public static List<Vector3> KHWestVectorList = new List<Vector3>
        {
            new Vector3(1043.2f, 1.6f, 1021.1f),
            new Vector3(1040.3f, 1.6f, 1021.6f),
            new Vector3(1038.8f, 1.6f, 1054.5f),
            new Vector3(1036.9f, 1.6f, 1076.8f),
            new Vector3(1034.9f, 1.6f, 1100.2f),
            new Vector3(1033.0f, 1.6f, 1122.2f),
            new Vector3(1046.0f, 1.6f, 1134.0f),
            new Vector3(1058.1f, 1.6f, 1146.0f),
            new Vector3(1071.4f, 1.6f, 1159.1f),
            new Vector3(1086.3f, 1.6f, 1173.9f),
            new Vector3(1098.8f, 1.6f, 1186.2f),
            new Vector3(1108.4f, 1.6f, 1195.7f),
            new Vector3(1122.2f, 1.6f, 1225.8f),
            new Vector3(1136.1f, 1.6f, 1255.5f),
            new Vector3(1142.5f, 1.6f, 1294.1f),
            new Vector3(1143.3f, 1.6f, 1335.6f),
            new Vector3(1144.1f, 1.6f, 1373.9f),
            new Vector3(1121.9f, 1.6f, 1401.9f),
            new Vector3(1109.1f, 1.6f, 1422.8f),
            new Vector3(1097.3f, 1.6f, 1436.3f),
            new Vector3(1071.0f, 1.6f, 1467.2f),
            new Vector3(1055.7f, 1.6f, 1460.7f),
            new Vector3(1044.7f, 1.6f, 1454.7f),
            new Vector3(1008.5f, 1.6f, 1434.9f),
            new Vector3(1003.8f, 1.6f, 1409.2f),
            new Vector3(1018.2f, 3.2f, 1403.5f),
            new Vector3(1010.7f, 2.2f, 1421.8f),
            new Vector3(1015.4f, 1.6f, 1447.4f),
            new Vector3(1043.6f, 1.6f, 1441.8f),
            new Vector3(1067.3f, 1.6f, 1428.6f),
            new Vector3(1092.0f, 1.6f, 1409.7f),
            new Vector3(1112.8f, 1.6f, 1386.9f),
            new Vector3(1116.0f, 1.6f, 1365.1f),
            new Vector3(1117.2f, 1.6f, 1339.7f),
            new Vector3(1118.7f, 1.6f, 1310.6f),
            new Vector3(1119.8f, 1.6f, 1287.8f),
            new Vector3(1116.3f, 1.6f, 1255.6f),
            new Vector3(1113.8f, 1.6f, 1235.3f),
            new Vector3(1097.6f, 1.6f, 1226.0f),
            new Vector3(1078.3f, 1.6f, 1210.0f),
            new Vector3(1062.7f, 1.6f, 1194.1f),
            new Vector3(1050.6f, 1.6f, 1176.6f),
            new Vector3(1036.4f, 1.6f, 1159.0f),
            new Vector3(1022.3f, 1.4f, 1146.7f),
            new Vector3(1007.4f, 1.6f, 1134.9f),
            new Vector3(1025.4f, 1.6f, 1127.1f),
            new Vector3(1046.5f, 1.6f, 1127.2f),
            new Vector3(1063.1f, 1.6f, 1122.9f),
            new Vector3(1053.7f, 1.6f, 1115.7f),
            new Vector3(1044.1f, 1.6f, 1101.4f),
            new Vector3(1037.5f, 1.6f, 1087.4f),
            new Vector3(1026.1f, 1.6f, 1081.3f),
            new Vector3(1028.2f, 1.6f, 1062.0f),
            new Vector3(1029.3f, 1.6f, 1043.5f),
            new Vector3(1029.7f, 1.6f, 1030.8f),
            new Vector3(1027.9f, 1.6f, 1015.0f),
            new Vector3(1023.7f, 1.6f, 1000.4f),
            new Vector3(1017.2f, 1.6f, 987.3f),
            new Vector3(1009.0f, 1.6f, 976.1f),
            new Vector3(1015.0f, 1.6f, 964.5f),
            new Vector3(1027.9f, 1.6f, 954.1f),
            new Vector3(1041.9f, 1.6f, 963.9f),
            new Vector3(1052.5f, 1.6f, 965.6f),
            new Vector3(1043.6f, 1.6f, 986.2f),
            new Vector3(1043.2f, 1.6f, 1011.8f),
            new Vector3(1041.2f, 1.6f, 1016.1f),
            new Vector3(1041.2f, 1.6f, 1016.1f)
        };

        public static List<Vector3> PathToEast = new List<Vector3>
        {
            new Vector3(1052.6f, 1.6f, 964.2f),
            new Vector3(1068.5f, 1.8f, 958.3f),
            new Vector3(1081.6f, 1.6f, 961.6f),
            new Vector3(1125.7f, 1.6f, 1008.0f),
            new Vector3(1116.3f, 1.6f, 1061.9f)
        };

        public static List<Vector3> PathToWest = new List<Vector3>
        {
            new Vector3(1119.5f, 1.6f, 1002.4f),
            new Vector3(1079.9f, 1.6f, 959.5f),
            new Vector3(1065.8f, 2.3f, 958.0f),
            new Vector3(1043.3f, 1.6f, 973.7f),
            new Vector3(1044.7f, 1.6f, 1016.6f),
        };

        #endregion

        public IState GetNextState()
        {
            List<SimpleChar> _hecks = DynelManager.NPCs
                .Where(x => x.Name.Contains("Heckler"))
                .Where(x => x.DistanceFrom(DynelManager.LocalPlayer) <= 30f)
                .Where(x => x.IsAlive && x.IsInLineOfSight)
                .ToList();

            if (KHBuddy.SideSelection.Beach == (KHBuddy.SideSelection)KHBuddy.KHBuddySettings["SideSelection"].AsInt32())
            {
                if (DynelManager.LocalPlayer.Position.DistanceFrom(KHBeachVectorList.Last()) < 3f && _hecks.Count >= 1)
                {
                    return new NukeState();
                }
            }
            if (KHBuddy.SideSelection.East == (KHBuddy.SideSelection)KHBuddy.KHBuddySettings["SideSelection"].AsInt32())
            {
                if (DynelManager.LocalPlayer.Position.DistanceFrom(KHEastVectorList.Last()) < 3f && _hecks.Count >= 1)
                {
                    KHBuddy.IPCChannel.Broadcast(new MoveEastMessage());
                    return new NukeState();
                }
            }
            if (KHBuddy.SideSelection.West == (KHBuddy.SideSelection)KHBuddy.KHBuddySettings["SideSelection"].AsInt32())
            {
                if (DynelManager.LocalPlayer.Position.DistanceFrom(KHWestVectorList.Last()) < 3f && _hecks.Count >= 1)
                {
                    KHBuddy.IPCChannel.Broadcast(new MoveWestMessage());
                    return new NukeState();
                }
            }
            if (KHBuddy.SideSelection.EastAndWest == (KHBuddy.SideSelection)KHBuddy.KHBuddySettings["SideSelection"].AsInt32())
            {
                if (KHBuddy._doingEast)
                {
                    if (DynelManager.LocalPlayer.Position.DistanceFrom(KHEastVectorList.Last()) < 3f && _hecks.Count >= 1)
                    {
                        _counterVec = 0;
                        return new NukeState();
                    }
                }
                if (KHBuddy._doingWest)
                {
                    if (DynelManager.LocalPlayer.Position.DistanceFrom(KHWestVectorList.Last()) < 3f && _hecks.Count >= 1)
                    {
                        _counterVec = 0;
                        return new NukeState();
                    }
                }
            }

            return null;
        }

        public void OnStateEnter()
        {
            _lastFollowTime = Time.NormalTime;
            //Chat.WriteLine("PullState::OnStateEnter");
        }

        public void OnStateExit()
        {
            //Chat.WriteLine("PullState::OnStateExit");
        }

        public void Tick()
        {
            if (KHBuddy.SideSelection.Beach == (KHBuddy.SideSelection)KHBuddy.KHBuddySettings["SideSelection"].AsInt32())
            {
                if (KHBuddy.GameTime > KHBuddy.RespawnTime
                    && DynelManager.LocalPlayer.Profession == Profession.Enforcer) 
                {
                    if (!MovementController.Instance.IsNavigating)
                    {
                        Spell.Find(270786, out Spell mongobuff);

                        if (_counterVec >= 0 && _counterVec < KHBeachVectorList.Count)
                        {
                            if (_counterVec <= 13)
                            {
                                _counterVec++;
                                MovementController.Instance.SetMovement(MovementAction.Update);
                                MovementController.Instance.SetDestination(KHBeachVectorList[_counterVec]);
                                _lastFollowTime = Time.NormalTime;
                            }

                            if (_counterVec >= 14 && mongobuff.IsReady && !Spell.HasPendingCast && Time.NormalTime - _lastFollowTime > 4.8
                                 && _counterVec < KHBeachVectorList.Count)
                            {
                                mongobuff.Cast();
                                CastedMongo = true;
                            }
                            else if (_counterVec >= 14 && CastedMongo == true && !mongobuff.IsReady && Time.NormalTime - _lastFollowTime > 4.8
                                 && _counterVec < KHBeachVectorList.Count)
                            {
                                _counterVec++;
                                MovementController.Instance.SetMovement(MovementAction.Update);
                                MovementController.Instance.SetDestination(KHBeachVectorList[_counterVec]);
                                _lastFollowTime = Time.NormalTime;
                                CastedMongo = false;
                            }
                        }
                    }
                }
            }
            if (KHBuddy.SideSelection.East == (KHBuddy.SideSelection)KHBuddy.KHBuddySettings["SideSelection"].AsInt32())
            {
                if (KHBuddy.GameTime > KHBuddy.RespawnTime
                    && DynelManager.LocalPlayer.Profession == Profession.Enforcer)
                {
                    if (!MovementController.Instance.IsNavigating)
                    {
                        Spell.Find(270786, out Spell mongobuff);

                        if (_counterVec >= 0 && _counterVec < KHEastVectorList.Count)
                        {
                            if (_counterVec <= 13)
                            {
                                _counterVec++;
                                MovementController.Instance.SetMovement(MovementAction.Update);
                                MovementController.Instance.SetDestination(KHEastVectorList[_counterVec]);
                                _lastFollowTime = Time.NormalTime;
                            }

                            if (_counterVec >= 14 && mongobuff.IsReady && !Spell.HasPendingCast && Time.NormalTime - _lastFollowTime > 4.8
                                 && _counterVec < KHEastVectorList.Count)
                            {
                                mongobuff.Cast();
                                CastedMongo = true;
                            }
                            else if (_counterVec >= 14 && CastedMongo == true && !mongobuff.IsReady && Time.NormalTime - _lastFollowTime > 4.8
                                 && _counterVec < KHEastVectorList.Count)
                            {
                                _counterVec++;
                                MovementController.Instance.SetMovement(MovementAction.Update);
                                MovementController.Instance.SetDestination(KHEastVectorList[_counterVec]);
                                _lastFollowTime = Time.NormalTime;
                                CastedMongo = false;
                            }
                        }
                    }
                }
            }

            if (KHBuddy.SideSelection.West == (KHBuddy.SideSelection)KHBuddy.KHBuddySettings["SideSelection"].AsInt32())
            {
                if (KHBuddy.GameTime > KHBuddy.RespawnTime
                    && DynelManager.LocalPlayer.Profession == Profession.Enforcer)
                {
                    if (!MovementController.Instance.IsNavigating)
                    {
                        Spell.Find(270786, out Spell mongobuff);

                        if (_counterVec >= 0 && _counterVec < KHEastVectorList.Count)
                        {
                            if (_counterVec <= 24)
                            {
                                _counterVec++;
                                MovementController.Instance.SetMovement(MovementAction.Update);
                                MovementController.Instance.SetDestination(KHWestVectorList[_counterVec]);
                                _lastFollowTime = Time.NormalTime;
                            }

                            if (_counterVec >= 25 && mongobuff.IsReady && !Spell.HasPendingCast && Time.NormalTime - _lastFollowTime > 4.8
                                 && _counterVec < KHWestVectorList.Count)
                            {
                                mongobuff.Cast();
                                CastedMongo = true;
                            }
                            else if (_counterVec >= 25 && CastedMongo == true && !mongobuff.IsReady && Time.NormalTime - _lastFollowTime > 4.8
                                 && _counterVec < KHWestVectorList.Count)
                            {
                                _counterVec++;
                                MovementController.Instance.SetMovement(MovementAction.Update);
                                MovementController.Instance.SetDestination(KHWestVectorList[_counterVec]);
                                _lastFollowTime = Time.NormalTime;
                                CastedMongo = false;
                            }
                        }
                    }
                }
            }

            if (KHBuddy.SideSelection.EastAndWest == (KHBuddy.SideSelection)KHBuddy.KHBuddySettings["SideSelection"].AsInt32())
            {
                if (KHBuddy._doingEast && !KHBuddy._doingWest)
                {
                    if (KHBuddy.GameTime > KHBuddy.RespawnTimeEast
                        && DynelManager.LocalPlayer.Profession == Profession.Enforcer)
                    {
                        if (!MovementController.Instance.IsNavigating)
                        {
                            Spell.Find(270786, out Spell mongobuff);

                            if (_counterVec >= 0 && _counterVec < KHEastVectorList.Count)
                            {
                                if (_counterVec <= 13)
                                {
                                    _counterVec++;
                                    MovementController.Instance.SetMovement(MovementAction.Update);
                                    MovementController.Instance.SetDestination(KHEastVectorList[_counterVec]);
                                    _lastFollowTime = Time.NormalTime;
                                }

                                if (_counterVec >= 14 && mongobuff.IsReady && !Spell.HasPendingCast && Time.NormalTime - _lastFollowTime > 4.8
                                    && _counterVec < KHEastVectorList.Count)
                                {
                                    mongobuff.Cast();
                                    CastedMongo = true;
                                }
                                else if (_counterVec >= 14 && CastedMongo == true && !mongobuff.IsReady && Time.NormalTime - _lastFollowTime > 4.8
                                    && _counterVec < KHEastVectorList.Count)
                                {
                                    _counterVec++;
                                    MovementController.Instance.SetMovement(MovementAction.Update);
                                    MovementController.Instance.SetDestination(KHEastVectorList[_counterVec]);
                                    _lastFollowTime = Time.NormalTime;
                                    CastedMongo = false;
                                }
                            }
                        }
                    }
                }

                if (!KHBuddy._doingEast && KHBuddy._doingWest)
                {
                    if (KHBuddy.GameTime > KHBuddy.RespawnTimeWest || !KHBuddy._init
                        && DynelManager.LocalPlayer.Profession == Profession.Enforcer)
                    {
                        if (!MovementController.Instance.IsNavigating)
                        {
                            Spell.Find(270786, out Spell mongobuff);

                            if (_counterVec >= 0 && _counterVec < KHWestVectorList.Count)
                            {
                                if (_counterVec <= 24)
                                {
                                    _counterVec++;
                                    MovementController.Instance.SetMovement(MovementAction.Update);
                                    MovementController.Instance.SetDestination(KHWestVectorList[_counterVec]);
                                    _lastFollowTime = Time.NormalTime;
                                }

                                if (_counterVec >= 25 && mongobuff.IsReady && !Spell.HasPendingCast && Time.NormalTime - _lastFollowTime > 4.8
                                     && _counterVec < KHWestVectorList.Count)
                                {
                                    mongobuff.Cast();
                                    CastedMongo = true;
                                }
                                else if (_counterVec >= 25 && CastedMongo == true && !mongobuff.IsReady && Time.NormalTime - _lastFollowTime > 4.8
                                     && _counterVec < KHWestVectorList.Count)
                                {
                                    _counterVec++;
                                    MovementController.Instance.SetMovement(MovementAction.Update);
                                    MovementController.Instance.SetDestination(KHWestVectorList[_counterVec]);
                                    _lastFollowTime = Time.NormalTime;
                                    CastedMongo = false;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
