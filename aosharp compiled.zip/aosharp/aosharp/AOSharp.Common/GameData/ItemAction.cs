﻿namespace AOSharp.Common.GameData
{
    public enum ItemActionInfo
    {
        UseCriteria = 3,
        Activate = 10
    }
}
