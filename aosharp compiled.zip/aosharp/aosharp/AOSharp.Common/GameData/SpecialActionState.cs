﻿namespace AOSharp.Common.GameData
{
    public enum SpecialActionState
    {
        Ready = 0,
        NotReady = 1
    }
}
