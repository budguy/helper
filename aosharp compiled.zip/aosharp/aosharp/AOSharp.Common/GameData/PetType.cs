﻿namespace AOSharp.Common.GameData
{
    public enum PetType
    {
        Unknown = 0x0,
        Attack = 0xA,
        Heal = 0xB,
        Support = 0xC,
        Social = 0xE
    }
}
