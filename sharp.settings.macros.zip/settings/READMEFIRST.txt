Read Me
-------

1- copy aosharpsettings.txt to C:\Users\******\AppData\Local\Funcom\Anarchy Online\********\Anarchy Online\scripts\text
2- in game you can make a macro with /macro sett /showfile aosharpsettings.txt or just open the file /showfile aosharpsettings.txt
3- change things in the text file to fit your resolution/needs.
4- PLAY AO!