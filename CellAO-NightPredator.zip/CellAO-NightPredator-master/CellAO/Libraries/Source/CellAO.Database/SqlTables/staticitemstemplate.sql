CREATE TABLE IF NOT EXISTS `staticitemstemplate` (
  `ID` int(32) NOT NULL,
  `Name` varchar(32) NOT NULL,
  `MonsterData` int(32) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
