CREATE TABLE  `charactersuploadednanos` (
  `ID` int(11) NOT NULL,
  `Nano` int(11) NOT NULL,
  PRIMARY KEY (`ID`,`Nano`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
