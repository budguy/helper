CREATE TABLE  `charactersaddmeshs` (
  `ID` int(11) NOT NULL,
  `playfield` int(11) NOT NULL,
  `meshvalue1` int(11) NOT NULL,
  `meshvalue2` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;