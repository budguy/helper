CREATE TABLE  `mobspawnsweaponpairs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `playfield` int(11) NOT NULL,
  `value1` int(11) NOT NULL,
  `value2` int(11) NOT NULL,
  `value3` int(11) NOT NULL,
  `value4` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;