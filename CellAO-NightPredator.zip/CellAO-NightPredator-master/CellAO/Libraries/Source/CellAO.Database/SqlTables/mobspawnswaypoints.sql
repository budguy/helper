CREATE TABLE  `mobspawnswaypoints` (
  `ID` int(11) NOT NULL,
  `Playfield` int(11) NOT NULL,
  `X` float NOT NULL,
  `Y` float NOT NULL,
  `Z` float NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;