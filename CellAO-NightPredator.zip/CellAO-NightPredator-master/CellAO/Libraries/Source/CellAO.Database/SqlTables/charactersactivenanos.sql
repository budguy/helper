CREATE TABLE  `charactersactivenanos` (
  `ID` int(10) unsigned NOT NULL,
  `nanoID` int(10) unsigned NOT NULL,
  `strain` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;