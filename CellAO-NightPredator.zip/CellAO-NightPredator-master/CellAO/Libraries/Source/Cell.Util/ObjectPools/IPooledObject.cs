namespace Cell.Util.ObjectPools
{
	public interface IPooledObject
	{
		void Cleanup();
	}
}