namespace Cell.Core.Localization
{
    internal class Resources : Cell_Core
    {
    }
}