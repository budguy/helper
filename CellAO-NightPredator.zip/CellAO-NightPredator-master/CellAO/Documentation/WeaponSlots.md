# Weapon slots #
`CellAO.Enums.WeaponSlots`   : `Int32`  

----------


**Hud1** = 1,

**Hud3** = 2,

**Util1** = 3,

**Util2** = 4,

**Util3** = 5,

**Righthand** = 6,

**Belt** = 7,

**LeftHand** = 8,

**Ncu1** = 9,

**Ncu2** = 10,

**Ncu3** = 11,

**Ncu4** = 12,

**Ncu5** = 13,

**Ncu6** = 14,

**Hud2** = 15


----------

*Copyright © 2013 CellAO Team*

*Created by MarkDownDocumentator Version 1.4.1.874 - Night Predator*


