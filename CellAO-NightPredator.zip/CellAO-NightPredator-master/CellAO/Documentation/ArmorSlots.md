# Armor slots #
`CellAO.Enums.ArmorSlots`   : `Int32`  

----------


**Neck** = 1,

**Head** = 2,

**Back** = 3,

**RightShoulder** = 4,

**Chest** = 5,

**LeftShoulder** = 6,

**RightArm** = 7,

**Hands** = 8,

**LeftArm** = 9,

**RightWrist** = 10,

**Legs** = 11,

**LeftWrist** = 12,

**RightFinger** = 13,

**Feet** = 14,

**LeftFinger** = 15


----------

*Copyright © 2013 CellAO Team*

*Created by MarkDownDocumentator Version 1.4.1.874 - Night Predator*


