# Identity Types #
`SmokeLounge.AOtomation.Messaging.GameData.IdentityType`   : `Int32`  

----------


**None** = 0,

**WeaponPage** = 101,

**ArmorPage** = 102,

**ImplantPage** = 103,

**Inventory** = 104,

**Bank** = 105,

**Backpack** = 107,

**KnuBotTradeWindow** = 108,

**OverflowWindow** = 110,

**TradeWindow** = 111,

**SocialPage** = 115,

**ShopInventory** = 1895,

**PlayerShopInventory** = 1936,

**Playfield2** = 40016,

**CanbeAffected** = 50000,

**WeaponInstance** = 51018,

**VendingMachine** = 51035,

**TempBag** = 51047,

**Corpse** = 51050,

**Playfield1** = 51100,

**Playfield** = 51101,

**NanoProgram** = 53019,

**GfxEffect** = 53030,

**TeamWindow** = 57001,

**Organization** = 57002,

**IncomingTradeWindow** = 57005,

**Playfield3** = 100001


----------

*Copyright © 2013 CellAO Team*

*Created by MarkDownDocumentator Version 1.4.1.874 - Night Predator*


