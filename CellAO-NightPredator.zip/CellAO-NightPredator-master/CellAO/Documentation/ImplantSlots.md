# Implant slots #
`CellAO.Enums.ImplantSlots`   : `Int32`  

----------


**Eyes** = 1,

**Head** = 2,

**Ears** = 3,

**Rightarm** = 4,

**Chest** = 5,

**Leftarm** = 6,

**Rightwrist** = 7,

**Waist** = 8,

**Leftwrist** = 9,

**Righthand** = 10,

**Legs** = 11,

**Lefthand** = 12,

**Feet** = 13


----------

*Copyright © 2013 CellAO Team*

*Created by MarkDownDocumentator Version 1.4.1.874 - Night Predator*


