# Inventory Errors #
`CellAO.Enums.InventoryError`  

----------


**OK**,

**HaveUniqueAlready**,

**InventoryIsFull**,

**CannotBeEquipped**,

**RequirementsNotMet**,

**Invalid**


----------

*Copyright © 2013 CellAO Team*

*Created by MarkDownDocumentator Version 1.4.1.874 - Night Predator*


