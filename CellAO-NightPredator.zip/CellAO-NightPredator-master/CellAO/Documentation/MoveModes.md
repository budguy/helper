# MoveModes #
`CellAO.Enums.MoveModes`  

----------


**None**,

**Rooted**,

**Walk**,

**Run**,

**Swim**,

**Crawl**,

**Sneak**,

**Fly**,

**Sit**,

**SocialTemp**,

**Nothing**,

**Sleep**,

**Lounge**


----------

*Copyright © 2013 CellAO Team*

*Created by MarkDownDocumentator Version 1.4.1.874 - Night Predator*


