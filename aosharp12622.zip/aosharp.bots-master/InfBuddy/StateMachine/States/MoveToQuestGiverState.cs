﻿using AOSharp.Common.GameData;
using AOSharp.Core;
using AOSharp.Core.UI;
using NavmeshMovementController;
using System;
using System.Threading;
using System.Threading.Tasks;


namespace InfBuddy
{
    public class MoveToQuestGiverState : IState
    {
        private const int _minWait = 2;
        private const int _maxWait = 4;

        private static float _entropy = 1.34f;

        private CancellationTokenSource _cancellationToken = new CancellationTokenSource();
        public IState GetNextState()
        {
            if (Playfield.ModelIdentity.Instance == Constants.OmniPandeGId || Playfield.ModelIdentity.Instance == Constants.ClanPandeGId)
                return new DiedState();

            if (!InfBuddy.NavMeshMovementController.IsNavigating && IsAtYutto())
                return new GrabMissionState();

            return null;
        }

        public void OnStateEnter()
        {
            Chat.WriteLine("MoveToQuestGiverState::OnStateEnter");

            InfBuddy._stateTimeOut = Time.NormalTime;

            if (!IsAtYutto())
            {
                Vector3 randoPos = Constants.QuestGiverPos;
                randoPos.AddRandomness((int)_entropy);

                int randomWait = Utils.Next(_minWait, _maxWait);

                if (DynelManager.LocalPlayer.Identity == InfBuddy.Leader
                    || InfBuddy._settings["Merge"].AsBool())
                    randomWait = 1;

                Chat.WriteLine($"Idling for {randomWait} seconds..");

                Task.Delay(randomWait * 1000).ContinueWith(x =>
                {
                    try
                    {
                        InfBuddy.NavMeshMovementController.SetNavMeshDestination(randoPos);
                    }
                    catch (Exception e)
                    {
                        InfBuddy.NavMeshMovementController.SetDestination(Constants.WallBugFixSpot);
                        InfBuddy.NavMeshMovementController.AppendNavMeshDestination(randoPos);
                    }
                }, _cancellationToken.Token);
            }
        }

        public void OnStateExit()
        {
            Chat.WriteLine("MoveToQuestGiverState::OnStateExit");

            _cancellationToken.Cancel();
        }

        public void Tick()
        {
            if (!IsAtYutto() && InfBuddy.NavMeshMovementController.IsNavigating
                && Time.NormalTime > InfBuddy._stateTimeOut + 40f)
            {
                Vector3 randoPos = Constants.QuestGiverPos;
                randoPos.AddRandomness((int)_entropy);

                InfBuddy._stateTimeOut = Time.NormalTime;

                InfBuddy.NavMeshMovementController.Halt();
                InfBuddy.NavMeshMovementController.SetNavMeshDestination(new Vector3(2717.5f, 24.6f, 3327.4f));
                InfBuddy.NavMeshMovementController.AppendNavMeshDestination(randoPos);
            }
        }

        private bool IsAtYutto()
        {
            return DynelManager.LocalPlayer.Position.DistanceFrom(Constants.QuestGiverPos) < 8f;
        }
    }
}
