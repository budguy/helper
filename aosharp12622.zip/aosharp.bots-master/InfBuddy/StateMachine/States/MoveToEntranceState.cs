﻿using AOSharp.Common.GameData;
using AOSharp.Core;
using AOSharp.Core.UI;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace InfBuddy
{
    public class MoveToEntranceState : IState
    {
        private const int _minWait = 5;
        private const int _maxWait = 7;

        private static bool _init = false;

        private CancellationTokenSource _cancellationToken = new CancellationTokenSource();

        public IState GetNextState()
        {
            if (Playfield.ModelIdentity.Instance == Constants.OmniPandeGId || Playfield.ModelIdentity.Instance == Constants.ClanPandeGId)
                return new DiedState();

            if (Playfield.ModelIdentity.Instance == Constants.NewInfMissionId)
            {
                if (InfBuddy.ModeSelection.Leech == (InfBuddy.ModeSelection)InfBuddy._settings["ModeSelection"].AsInt32())
                    return new LeechState();

                if (DynelManager.LocalPlayer.Identity != InfBuddy.Leader && InfBuddy.ModeSelection.Roam == (InfBuddy.ModeSelection)InfBuddy._settings["ModeSelection"].AsInt32())
                    return new RoamState();

                return new MoveToQuestStarterState();
            }

            return null;
        }

        public void OnStateEnter()
        {
            Chat.WriteLine("MoveToEntranceState::OnStateEnter");

            InfBuddy._stateTimeOut = Time.NormalTime;

            int randomWait = Utils.Next(_minWait, _maxWait);

            if (DynelManager.LocalPlayer.Identity == InfBuddy.Leader)
                randomWait = 4;

            Chat.WriteLine($"Idling for {randomWait} seconds..");

            Task.Delay(randomWait * 1000).ContinueWith(x =>
            {
                InfBuddy.NavMeshMovementController.SetNavMeshDestination(Constants.EntrancePos);
                InfBuddy.NavMeshMovementController.AppendDestination(Constants.EntranceFinalPos);
                _init = true;
            }, _cancellationToken.Token);
        }

        public void OnStateExit()
        {
            Chat.WriteLine("MoveToEntranceState::OnStateExit");

            _init = false;
            _cancellationToken.Cancel();
        }

        public void Tick()
        {
            if (Playfield.ModelIdentity.Instance != Constants.InfernoId) { return; }

            if (InfBuddy.NavMeshMovementController.IsNavigating
                && Time.NormalTime > InfBuddy._stateTimeOut + 40f
                && _init)
            {
                InfBuddy._stateTimeOut = Time.NormalTime;

                InfBuddy.NavMeshMovementController.Halt();
                InfBuddy.NavMeshMovementController.SetNavMeshDestination(new Vector3(2772.6f, 24.6f, 3322.4f).Randomize(1f));
            }

            if (!InfBuddy.NavMeshMovementController.IsNavigating && _init)
            {
                InfBuddy.NavMeshMovementController.SetNavMeshDestination(Constants.EntrancePos);
                InfBuddy.NavMeshMovementController.AppendDestination(Constants.EntranceFinalPos);
            }
        }
    }
}
