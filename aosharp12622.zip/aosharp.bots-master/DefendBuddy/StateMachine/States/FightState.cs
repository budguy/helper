﻿using AOSharp.Common.GameData;
using AOSharp.Core;
using AOSharp.Core.Inventory;
using AOSharp.Core.Movement;
using AOSharp.Core.UI;
using System.Collections.Generic;
using System.Linq;

namespace DefendBuddy
{
    public class FightState : PositionHolder, IState
    {
        public const double _fightTimeout = 45f;
        
        private double _fightStartTime;
        public static float _tetherDistance;

        public static int _aggToolCounter = 0;

        public static List<Identity> corpseToLootIdentity = new List<Identity>();
        public static List<Corpse> corpsesToLoot = new List<Corpse>();
        public static List<Identity> lootedCorpses = new List<Identity>();

        public static List<int> _ignoreTargetIdentity = new List<int>();

        private SimpleChar _target;

        public FightState(SimpleChar target) : base(Constants._posToDefend, 3f, 1)
        {
            _target = target;
        }

        public IState GetNextState()
        {
            if (_target?.IsValid == false ||
               _target?.IsAlive == false ||
               _target?.IsInLineOfSight == false ||
               (Time.NormalTime > _fightStartTime + _fightTimeout && _target?.MaxHealth <= 999999))
            {
                _target = null;

                if (DefendBuddy._settings["Looting"].AsBool())
                {
                    List<SimpleChar> mobs = DynelManager.NPCs
                        .Where(c => c.Position.DistanceFrom(Constants._posToDefend) <= DefendBuddy.AttackRange
                            && !Constants._ignores.Contains(c.Name) && c.IsAlive && c.IsInLineOfSight)
                        .ToList();

                    if (mobs?.Count == 0)
                    {
                        return new LootState();
                    }
                    else
                    {
                        return new DefendState();
                    }
                }
                else
                    return new DefendState();
            }

            return null;
        }

        public void OnStateEnter()
        {
            //Chat.WriteLine("FightState::OnStateEnter");

            _fightStartTime = Time.NormalTime;
        }

        public void OnStateExit()
        {
            //Chat.WriteLine("FightState::OnStateExit");

            _aggToolCounter = 0;

            if (DynelManager.LocalPlayer.IsAttacking)
                DynelManager.LocalPlayer.StopAttack();
        }

        public void Tick()
        {
            if (_target == null)
                return;

            if (DefendBuddy.GetLeader() != null)
            {
                if (DynelManager.LocalPlayer.FightingTarget != null && DynelManager.LocalPlayer.FightingTarget.MaxHealth >= 1000000 &&
                    (DynelManager.LocalPlayer.FightingTarget.Buffs.Contains(253953) || DynelManager.LocalPlayer.FightingTarget.Buffs.Contains(205607)
                    || DynelManager.LocalPlayer.FightingTarget.Buffs.Contains(NanoLine.ShovelBuffs)))
                {
                    DynelManager.LocalPlayer.StopAttack();
                    return;
                }

                if (DynelManager.LocalPlayer.FightingTarget != null && DynelManager.LocalPlayer.FightingTarget.IsPlayer)
                {
                    DynelManager.LocalPlayer.Attack(_target);
                    return;
                }

                if (DynelManager.LocalPlayer.FightingTarget == null 
                    && !DynelManager.LocalPlayer.IsAttacking && !DynelManager.LocalPlayer.IsAttackPending)
                {
                    if (_target.Position.DistanceFrom(DynelManager.LocalPlayer.Position) <= DefendBuddy.Config.CharSettings[Game.ClientInst].AttackRange)
                    {
                        if (DefendBuddy.ModeSelection.Path == (DefendBuddy.ModeSelection)DefendBuddy._settings["ModeSelection"].AsInt32())
                            MovementController.Instance.Halt();

                        DynelManager.LocalPlayer.Attack(_target);
                        Chat.WriteLine($"Attacking {_target.Name}.");
                        _fightStartTime = Time.NormalTime;
                    }
                }
                else
                {
                    if (_target.MaxHealth >= 1000000)
                    {
                        if (DefendBuddy._switchMob.Count >= 1)
                        {
                            if (DynelManager.LocalPlayer.FightingTarget != null)
                            {
                                //Idk why this is here some correction no doubt
                                if (DefendBuddy._switchMob.FirstOrDefault().Health == 0) { return; }

                                _target = DefendBuddy._switchMob.FirstOrDefault();
                                DynelManager.LocalPlayer.Attack(_target);
                                Chat.WriteLine($"Switching to target {_target.Name}.");
                                _fightStartTime = Time.NormalTime;
                                return;
                            }
                        }
                        else if (DefendBuddy._mob.Count >= 1)
                        {
                            if (DynelManager.LocalPlayer.FightingTarget != null)
                            {
                                //Idk why this is here some correction no doubt
                                if (DefendBuddy._mob.FirstOrDefault().Health == 0) { return; }

                                _target = DefendBuddy._mob.FirstOrDefault();
                                DynelManager.LocalPlayer.Attack(_target);
                                Chat.WriteLine($"Switching to target {_target.Name}.");
                                _fightStartTime = Time.NormalTime;
                                return;
                            }
                        }
                    }
                    else if (DefendBuddy._switchMob.Count >= 1 && _target.Name != DefendBuddy._switchMob.FirstOrDefault().Name)
                    {
                        if (DynelManager.LocalPlayer.FightingTarget != null)
                        {
                            //Idk why this is here some correction no doubt
                            if (DefendBuddy._switchMob.FirstOrDefault().Health == 0) { return; }

                            _target = DefendBuddy._switchMob.FirstOrDefault();
                            DynelManager.LocalPlayer.Attack(_target);
                            Chat.WriteLine($"Switching to target {_target.Name}.");
                            _fightStartTime = Time.NormalTime;
                            return;
                        }
                    }
                }
            }

            if (_target.IsInLineOfSight
                && !DynelManager.LocalPlayer.IsAttacking && !DynelManager.LocalPlayer.IsAttackPending
                && DefendBuddy.ModeSelection.Taunt == (DefendBuddy.ModeSelection)DefendBuddy._settings["ModeSelection"].AsInt32())
            {
                if (DefendBuddy.GetLeader() != null)
                {

                    if (_target.Position.DistanceFrom(DynelManager.LocalPlayer.Position) > DefendBuddy.Config.CharSettings[Game.ClientInst].AttackRange)
                    {
                        if (_aggToolCounter >= 5)
                        {
                            //_ignoreTargetIdentity.Add(_target.Identity.Instance);
                            MovementController.Instance.SetDestination(_target.Position);
                        }
                        else if (Inventory.Find(83920, 83919, out Item aggroTool))
                        {
                            if (!Item.HasPendingUse && !DynelManager.LocalPlayer.Cooldowns.ContainsKey(Stat.Psychology))
                            {
                                aggroTool.Use(_target, true);
                                _aggToolCounter++;
                                return;
                            }
                        }
                        else if (Inventory.Find(244655, 244655, out Item scorpioTool))
                        {
                            if (!Item.HasPendingUse && !DynelManager.LocalPlayer.Cooldowns.ContainsKey(Stat.Psychology))
                            {
                                scorpioTool.Use(_target, true);
                                _aggToolCounter++;
                                return;
                            }
                        }
                        else if (Inventory.Find(83919, 83919, out Item aggroMultiTool)) // To-do could be wrong
                        {
                            if (!Item.HasPendingUse && !DynelManager.LocalPlayer.Cooldowns.ContainsKey(Stat.Psychology))
                            {
                                aggroMultiTool.Use(_target, true);
                                _aggToolCounter++;
                                return;
                            }
                        }
                        else if (Inventory.Find(253186, 253186, out Item EmertoLow))
                        {
                            if (!Item.HasPendingUse && !DynelManager.LocalPlayer.Cooldowns.ContainsKey(Stat.Psychology))
                            {
                                EmertoLow.Use(_target, true);
                                _aggToolCounter++;
                                return;
                            }
                        }
                        else if (Inventory.Find(253187, 253187, out Item EmertoHigh))
                        {
                            if (!Item.HasPendingUse && !DynelManager.LocalPlayer.Cooldowns.ContainsKey(Stat.Psychology))
                            {
                                EmertoHigh.Use(_target, true);
                                _aggToolCounter++;
                                return;
                            }
                        }
                    }
                }
            }
            //if (MovementController.Instance.IsNavigating && _target.IsInLineOfSight
            //    && _target.Position.DistanceFrom(DynelManager.LocalPlayer.Position) <= DefendBuddy.Config.CharSettings[Game.ClientInst].AttackRange
            //    && DefendBuddy._settings["Pathing"].AsBool())
            //{
            //    MovementController.Instance.Halt();
            //}

            if (!_target.IsMoving &&
                _target.Position.DistanceFrom(DynelManager.LocalPlayer.Position) > DefendBuddy.Config.CharSettings[Game.ClientInst].AttackRange
                && DefendBuddy.ModeSelection.Path == (DefendBuddy.ModeSelection)DefendBuddy._settings["ModeSelection"].AsInt32())
            {
                MovementController.Instance.SetDestination(_target.Position);
            }
        }
    }
}
