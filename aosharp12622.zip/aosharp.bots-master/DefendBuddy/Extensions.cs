﻿using AOSharp.Common.GameData;

namespace DefendBuddy
{
    public static class Extensions
    {
        public static void AddRandomness(this ref Vector3 pos, int entropy)
        {
            pos.X += Utils.Next(-entropy, entropy);
            pos.Z += Utils.Next(-entropy, entropy);
        }
    }
}
