﻿using AOSharp.Common.GameData;

namespace AXPBuddy
{
    public static class Constants
    {
        public static Vector3 S13EntrancePos = new Vector3(145.7f, 0.5f, 206.5f);
        public static Vector3 S13ZoneOutPos = new Vector3(149.5f, 0.5f, 206.4f);
        public static Vector3 S13ExitPos = new Vector3(168f, 36.4f, 49.5f);
        public static Vector3 S13StartPos = new Vector3(150.7f, 36.4f, 42.0f);
        public static Vector3 S13GoalPos = new Vector3(170.3f, 6.2f, 486.1f); //170.3f, 6.2f, 486.1f           197f, 5.1f, 472f
        public static Vector3 S13CorrectionPos = new Vector3(73.7f, 31.6f, 333.1f);
        public static Vector3 testpos = new Vector3(132.9f, 36.4f, 49.8f);
        public static Vector3 XanHubPos = new Vector3(585.4f, 0.0f, 740.2);

        //public static Vector3 S13GoalPos = new Vector3(139.1f, 36.24f, 43.9f); //RapidReformTest
        public static Vector3 S28EntrancePos = new Vector3(232.6f, 1.0f, 169.9f);
        public static Vector3 S35EntrancePos = new Vector3(230.9f, 0.3f, 239.4f);
        public static Vector3 S35ExitPos = new Vector3(520.5f, 4.0f, 58.5f);
        public const int S13Id = 4365;
        public const int S28Id = 4367;
        public const int S35Id = 4366;
        public const int APFHubId = 4368;
        public const int UnicornHubId = 4364;
        public const int XanHubId = 6013;
        public const float MaxPullDistance = 30;
        public const float FightDistance = 3;
    }
}
