﻿using AOSharp.Common.GameData;
using AOSharp.Core;
using AOSharp.Core.UI;
using AOSharp.Pathfinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace AXPBuddy
{
    //I like this template over the RoamState in InfBuddy (Same concept)
    public class PatrolState : IState
    {
        private SimpleChar _target;

        public static bool _init = false;

        public IState GetNextState()
        {
            if (Playfield.ModelIdentity.Instance == Constants.XanHubId
                || Playfield.ModelIdentity.Instance == Constants.UnicornHubId
                || (Playfield.ModelIdentity.Instance == Constants.APFHubId
                    && DynelManager.LocalPlayer.Position.DistanceFrom(Constants.S13ZoneOutPos) > 10f))
                return new DiedState();

            if (DynelManager.LocalPlayer.Position.DistanceFrom(Constants.S13GoalPos) <= 10f
                && Team.IsInTeam)
                Team.Disband();

            if (Playfield.ModelIdentity.Instance == Constants.APFHubId && !Team.IsInTeam)
                return new ReformState();

            if (_target != null)
                return new FightState(_target);

            return null;
        }

        public void OnStateEnter()
        {
            Chat.WriteLine("PatrolState::OnStateEnter");
        }

        public void OnStateExit()
        {
            Chat.WriteLine("PatrolState::OnStateExit");
        }

        private void HandleScan()
        {
            SimpleChar mob = DynelManager.NPCs
                .Where(c => c.Health > 0
                    && c.IsInLineOfSight
                    && c.Position.DistanceFrom(DynelManager.LocalPlayer.Position) <= 28f)
                .OrderBy(c => c.HealthPercent)
                .ThenBy(c => c.Position.DistanceFrom(DynelManager.LocalPlayer.Position))
                .FirstOrDefault(c => !AXPBuddy._namesToIgnore.Contains(c.Name));

            if (mob != null)
            {
                _target = mob;
                Chat.WriteLine($"Found target: {_target.Name}");
            }
            else if (!Team.Members.Any(c => c.Character == null)
                    && !Team.Members.Where(c => c.Character != null
                       && (c.Character.HealthPercent < 66 || c.Character.NanoPercent < 66))
                       .Any()
                    && DynelManager.LocalPlayer.MovementState != MovementState.Sit && !AXPBuddy.Rooted()
                    && DynelManager.LocalPlayer.Position.DistanceFrom(Constants.S13GoalPos) > 5f)
            {
                if (!AXPBuddy._passedCorrectionPos)
                {
                    //Reason: Correction - pathing on enter
                    if (!_init && Team.Members.Any(c => c.Character == null)) { return; }

                    if (DynelManager.LocalPlayer.Position.DistanceFrom(Constants.S13CorrectionPos) < 5f)
                        AXPBuddy._passedCorrectionPos = true;
                    else
                        AXPBuddy.NavMeshMovementController.SetNavMeshDestination(Constants.S13CorrectionPos);
                }
                else
                    AXPBuddy.NavMeshMovementController.SetNavMeshDestination(Constants.S13GoalPos);
            }
        }

        public void Tick()
        {
            if (!Team.IsInTeam) { return; }

            //Reason: Correction - pathing on enter
            if (!_init && !Team.Members.Any(c => c.Character == null))
                _init = true;

            foreach (TeamMember member in Team.Members)
            {
                if (!ReformState._teamCache.Contains(member.Identity))
                    ReformState._teamCache.Add(member.Identity);
            }

            if (AXPBuddy._died || (!AXPBuddy._initMerge && AXPBuddy._settings["Merge"].AsBool()))
            {
                if (!AXPBuddy._initMerge)
                    AXPBuddy._initMerge = true;

                if (AXPBuddy._leaderPos != Vector3.Zero)
                    AXPBuddy.NavMeshMovementController.SetNavMeshDestination(AXPBuddy._leaderPos);
                else
                    AXPBuddy.NavMeshMovementController.SetNavMeshDestination(Constants.S13GoalPos);
            }

            if (DynelManager.LocalPlayer.Identity != AXPBuddy.Leader)
            {
                AXPBuddy._leader = Team.Members
                    .Where(c => c.Character?.Health > 0
                        && c.Character?.IsValid == true
                        && c.IsLeader)
                    .FirstOrDefault().Character;

                if (AXPBuddy._leader != null)
                {
                    AXPBuddy._leaderPos = (Vector3)AXPBuddy._leader?.Position;

                    if (AXPBuddy._died)
                        AXPBuddy._died = false;

                    if (AXPBuddy._leader.FightingTarget != null)
                    {
                        SimpleChar targetMob = DynelManager.NPCs
                            .Where(c => c.Health > 0
                                && c.Identity == (Identity)AXPBuddy._leader.FightingTarget?.Identity)
                            .FirstOrDefault(c => !AXPBuddy._namesToIgnore.Contains(c.Name));

                        if (targetMob != null)
                        {
                            _target = targetMob;
                            Chat.WriteLine($"Found target: {_target.Name}");
                        }
                    }
                    else if (DynelManager.LocalPlayer.Position.DistanceFrom(AXPBuddy._leaderPos) > 1f
                        && DynelManager.LocalPlayer.MovementState != MovementState.Sit && !AXPBuddy.Rooted())
                        AXPBuddy.NavMeshMovementController.SetNavMeshDestination(AXPBuddy._leaderPos);
                }
            }
            else if (!AXPBuddy._died)
                HandleScan();
        }
    }
}