﻿namespace AOSharp.Core
{
    public static class Offsets
    {
        public class RTTIDynamicCast
        {
            public class SimpleItem_t
            {
                public const int n3Dynel_t = 0xB0; //mdisp: 176
            }
        }
    }
}
