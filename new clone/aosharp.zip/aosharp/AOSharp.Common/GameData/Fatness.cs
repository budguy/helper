﻿namespace AOSharp.Common.GameData
{
    public enum Fatness
    {
        Thin = 0,
        Normal = 1,
        Fat = 2
    }
}
