﻿namespace AOSharp.Common.GameData
{
    public enum Gender
    {
        None = 0,
        Uni = 1,
        Male = 2,
        Female = 3
    }
}
