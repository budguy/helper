﻿namespace AOSharp.Common.GameData
{
    public enum Breed
    {
        None = 0,
        Solitus = 1,
        Opifex = 2,
        Nanomage = 3,
        Atrox = 4,
        Special = 5,
        Monster = 6,
        HumanMonster = 7
    }
}
