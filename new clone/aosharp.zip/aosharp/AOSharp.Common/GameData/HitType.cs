﻿namespace AOSharp.Common.GameData
{
    public enum HitType
    {
        Glancing = 0x2,
        Normal = 0x3,
        Critical = 0x4
    }
}
