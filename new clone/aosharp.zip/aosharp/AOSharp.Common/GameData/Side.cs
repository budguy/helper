﻿namespace AOSharp.Common.GameData
{
    public enum Side
    {
        Neutral = 0,
        Clan = 1,
        OmniTek = 2,
        Monster = 3,
        Advisor = 4,
        Guardian = 5,
        Gm = 6,
        Mixed = 7
    }
}
