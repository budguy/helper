﻿namespace AOSharp.Common.GameData
{
    public enum TowerClass
    {
        ControlTower = 1,
        Turret = 2,
        Conductor = 4
    }
}
