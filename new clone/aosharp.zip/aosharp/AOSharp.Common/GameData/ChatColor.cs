﻿namespace AOSharp.Common.GameData
{
    public enum ChatColor
    {
        White = 0,
        LightBlue = 4,
        Yellow = 5,
        Green = 8,
        DarkPink = 9,
        Black = 11,
        Red = 12,
        DarkBlue = 14,
        Gold = 17,
        Orange = 27
    }
}
