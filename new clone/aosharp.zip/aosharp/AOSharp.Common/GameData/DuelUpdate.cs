﻿namespace AOSharp.Common.GameData
{
    public enum DuelUpdate
    {
        Challenge = 0,
        Accept = 1,
        Decline = 2,
        Stop = 3,
    }
}
