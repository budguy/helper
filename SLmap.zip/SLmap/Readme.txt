Updated ingame map - latest releases

** Rubi-Ka **

For RK map, please teleport to Saavick's lab :
http://www.aofroobs.com/viewtopic.php?f=20&t=10481

***************************************************

** Shadowlands **

For SL map, you're already in the right place !
Download latest @ https://rubi-ka.net/bitnykk

EASY INSTALLATION :
With any old version removed, extract archive in ao/cd_image/textures/PlanetMap ; you should obtain a new "SLmap" folder containing 4 files : SLmap.bin, SLmap.xml, SLmap.txt & Readme.txt
At this point, just open ingame worldmap once in SL by hitting "P" & then click the "i" upperleft of that window > Select Map > choose SLmap link from the list ; that's all done !11!!1

VERSION & CHANGES :
1.0 - december 2015 => playground removed ; backgrounds minimalized ; borders cleaned ; LoX enlighted ; layers optimized ; closeview repaired ; title font changed ; garden/sanct nanos refreshed ; new maps/NPC added.

GOALS BEHIND :
Idea is to go on from the best SL map we had so far, Onack's AoSL, and keep informations updated in minimal filesize accordingly to last AO patches.

NEW DISTRIBUTION :
Layer 1 => small map with minimal zone informations / Layer 2 => everything important dynabosses included / Layer 3 => nanos, quest related & various NPCs

FUTURE CHANGES :
Planning redesign of map blurry/pixelized elements (...) ; may be font review if doesn't make too much rework ; introduce new additions AO team will patch + community feedbacks & suggestions.

OFFICIAL THREADS :
http://www.ao-universe.com/forum/viewtopic.php?t=5752 preferably or http://forums.anarchy-online.com/showthread.php?615312
Please post your feedback (about the SL map only !) in any of these, what's relevant and doable will be taken in consideration.

SPECIAL THANX :
Onack for an inestimable work over years ; Novagen for hosting & sources ; Saavick for test & tricks ; Demoder & Cell-team for toolbox ; Alliance of Rimor for infos ; other players that helped (you know who you are).