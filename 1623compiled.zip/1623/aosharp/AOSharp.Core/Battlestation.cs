﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmokeLounge.AOtomation.Messaging.Messages.N3Messages;

namespace AOSharp.Core
{
    public class Battlestation
    {
        public static void JoinQueue(Side side)
        {
            throw new NotImplementedException();
        }

        public static void LeaveQueue()
        {
            throw new NotImplementedException();
        }

        public enum Side
        {
            Red = 0,
            Blue = 1
        }
    }
}
