﻿using AOSharp.Core;
using AOSharp.Core.UI;
using AOSharp.Common.GameData;
using AOSharp.Common.Unmanaged.Interfaces;
using System.Linq;
using System.Threading.Tasks;

namespace ResearchManager
{
    public class ResearchManager : AOPluginEntry
    {
        protected Settings _settings;

        public static bool _asyncToggle = false;

        private static double _tick;

        private static string _perkName = N3EngineClientAnarchy.GetPerkName(DynelManager.LocalPlayer.GetStat(Stat.PersonalResearchGoal));

        public static string PluginDir;

        public override void Run(string pluginDir)
        {
            _settings = new Settings("Research");
            PluginDir = pluginDir;

            Game.OnUpdate += OnUpdate;

            _settings.AddVariable("Toggle", false);

            RegisterSettingsWindow("Research Manager", $"ResearchManagerSettingsView.xml");

            Chat.WriteLine("Research Manager Loaded!");
            Chat.WriteLine("/researchmanager for settings.");
        }

        public override void Teardown()
        {
            SettingsController.CleanUp();
        }
        protected void RegisterSettingsWindow(string settingsName, string xmlName)
        {
            SettingsController.RegisterSettingsWindow(settingsName, PluginDir + "\\UI\\" + xmlName, _settings);
        }

        private void OnUpdate(object s, float deltaTime)
        {
            //if (Keyboard.IsKeyDown(Key.LeftCtrl) && Keyboard.IsKeyDown(Key.F1))
            //{
            //    if (SettingsController.settingsWindow == null)
            //        SettingsController.settingsWindow = Window.Create(new Rect(50, 50, 280, 280), "Research Manager", "Settings", WindowStyle.Default, WindowFlags.None);

            //    if (SettingsController.settingsWindow != null && SettingsController.settingsWindow?.IsVisible == false)
            //    {
            //        SettingsController.AppendSettingsTab("Research Manager", SettingsController.settingsWindow);
            //    }
            //}

            if (_settings["Toggle"].AsBool() && !Game.IsZoning
                && Time.NormalTime > _tick + 5f)
            {
                _tick = Time.NormalTime;

                if (DynelManager.LocalPlayer.GetStat(Stat.PersonalResearchGoal) > 0
                    && _perkName != N3EngineClientAnarchy.GetPerkName(DynelManager.LocalPlayer.GetStat(Stat.PersonalResearchGoal)))
                {
                    _perkName = N3EngineClientAnarchy.GetPerkName(DynelManager.LocalPlayer.GetStat(Stat.PersonalResearchGoal));
                }

                if (!Research.Goals.Where(c => N3EngineClientAnarchy.GetPerkName(c.ResearchId) == _perkName)
                        .FirstOrDefault().Available
                    || (DynelManager.LocalPlayer.GetStat(Stat.PersonalResearchGoal) == 0
                        && !Research.Goals.Where(c => N3EngineClientAnarchy.GetPerkName(c.ResearchId) == _perkName)
                            .FirstOrDefault().Available))
                {
                    Chat.WriteLine($"current stat value - personal research goal {DynelManager.LocalPlayer.GetStat(Stat.PersonalResearchGoal)}");
                    Chat.WriteLine($"current perk name - {N3EngineClientAnarchy.GetPerkName(DynelManager.LocalPlayer.GetStat(Stat.PersonalResearchGoal))}");

                    ResearchGoal _next = Research.Goals.Where(c => N3EngineClientAnarchy.GetPerkName(c.ResearchId)
                        != _perkName && c.Available)
                        .OrderBy(c => c.ResearchId)
                        .FirstOrDefault();

                    Chat.WriteLine($"next perk name - {N3EngineClientAnarchy.GetPerkName(_next.ResearchId)}");
                    Chat.WriteLine($"next perk id - {_next.ResearchId}");

                    Research.Train(_next.ResearchId);
                }
            }
        }
    }
}
