﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FollowManager.IPCMessages
{
    public enum IPCOpcode
    {
        Follow = 400
    }
}
