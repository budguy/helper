﻿namespace AOSharp.Bootstrap.IPC
{
    public enum HookOpCode : byte
    {
        LoadAssembly
    }
}
