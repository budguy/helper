<form id="loginForm" name="loginForm" method="post" action="register-exec.php">
<input type="submit" name="Submit" value="Register" />
  <table width="300" border="0" align="center" cellpadding="2" cellspacing="0">
    <tr>
      <th>First Name </th>
      <td><input onfocus="this.value=''" value="myFirstname" name="fname" type="text" class="textfield" id="fname" /></td>
    </tr>
    <tr>
      <th>Last Name </th>
      <td><input onfocus="this.value=''" value="myLastname" name="lname" type="text" class="textfield" id="lname" /></td>
    </tr>
    <tr>
      <th>Email </th>
      <td><input onfocus="this.value=''" value="some@email.com" name="email" type="text" class="textfield" id="email" /></td>
    </tr>
    <tr>
      <th width="124">Login</th>
      <td width="168"><input onfocus="this.value=''" value="myUsername" name="login" type="text" class="textfield" id="login" /></td>
    </tr>
    <tr>
      <th>Password</th>
      <td><input onfocus="this.value=''" value="myPassword" name="password" type="password" class="textfield" id="password" /></td>
    </tr>
    <tr>
      <th>Confirm Password </th>
      <td><input onfocus="this.value=''" value="myPassword" name="cpassword" type="password" class="textfield" id="cpassword" /></td>
    </tr>

  </table>
</form>