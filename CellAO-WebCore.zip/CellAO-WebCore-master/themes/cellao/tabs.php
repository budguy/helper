<?php

echo '<li id="'.$switch1.'">';
echo '<a href="/index.php"><span>.: MAIN :.</span></a></li>';
echo '<li id="'.$switch2.'">';
echo '<a href="/member-profile.php"><span>.: MY PROFILE :.</span></a></li>';
echo '<li id="'.$switch3.'">';
echo '<a href="/admins/administrator.php?changeuser=yes"><span>.: ADMIN :.</span></a></li>';
echo '<li id="'.$switch4.'">';
echo '<a href="#"><span>.: FORUM :.</span></a></li>';
echo '<li id="'.$switch5.'">';
echo '<a href="#"><span>.: CHAT :.</span></a></li>';
echo '<li id="'.$switch6.'">';
echo '<a href="#"><span>.: SUPPORT :.</span></a></li>';
echo '<li id="'.$switch7.'">';
echo '<a href="#"><span>.: ABOUT :.</span></a></li>';

?>