<?php
// Define DB Internals for SimpleSQL CellAO WebCore
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASSWORD', '');
	define('DB_DATABASE', 'cellao');
// Define other variables
	define('THEME', 'themes/cellao/');
?>
?>